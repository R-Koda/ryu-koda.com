import os, sys, hashlib, json, filecmp
from pathlib import Path
from collections import defaultdict
root = Path(sys.argv[1] if len(sys.argv)>1 else 'sample')
if not root.is_dir():
    raise SystemExit('対象フォルダがありません')
groups = defaultdict(list)
errors = []
for folder, dirs, files in os.walk(root, followlinks=False):
    dirs[:] = sorted(d for d in dirs if not d.startswith('.') and not (Path(folder)/d).is_symlink())
    for name in sorted(files):
        p = Path(folder)/name
        if name.startswith('.') or p.is_symlink() or not p.is_file():
            continue
        try:
            h = hashlib.sha256()
            with p.open('rb') as f:
                for chunk in iter(lambda: f.read(1024*1024), b''):
                    h.update(chunk)
            groups[(p.stat().st_size,h.hexdigest())].append(p)
        except OSError as e:
            errors.append({'file':str(p),'error':str(e)})
result=[]
for candidates in groups.values():
    if len(candidates)<2: continue
    first=candidates[0]
    try:
        if all(filecmp.cmp(first,p,shallow=False) for p in candidates[1:]):
            result.append([str(p) for p in candidates])
    except OSError as e:
        errors.append({'file':str(first),'error':str(e)})
print(json.dumps({'duplicate_groups':result,'errors':errors},ensure_ascii=False,indent=2))
