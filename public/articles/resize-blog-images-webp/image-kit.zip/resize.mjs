import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
const input = process.argv[2] ?? 'input';
const output = process.argv[3] ?? 'output';
if (path.resolve(input) === path.resolve(output)) throw Error('入力と出力は別のフォルダにしてください');
await fs.mkdir(output, {recursive:true});
const results=[];
for (const entry of await fs.readdir(input, {withFileTypes:true})) {
  if (!entry.isFile() || !/\.(png|jpe?g)$/i.test(entry.name)) continue;
  const source=path.join(input,entry.name);
  const target=path.join(output,entry.name+'.webp');
  // wx prevents overwriting an existing output file.
  const handle=await fs.open(target,'wx');
  try {
    const buffer=await sharp(source).rotate().resize({width:1200,withoutEnlargement:true}).webp({quality:85}).toBuffer();
    await handle.writeFile(buffer);
    const meta=await sharp(buffer).metadata();
    results.push({file:entry.name,before:(await fs.stat(source)).size,after:buffer.length,width:meta.width,height:meta.height});
  } finally {await handle.close();}
}
console.log(JSON.stringify(results,null,2));
